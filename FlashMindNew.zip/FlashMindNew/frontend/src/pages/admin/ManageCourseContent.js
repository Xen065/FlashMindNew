/**
 * ============================================
 * Manage Course Content & Questions Page
 * ============================================
 * Comprehensive UI for managing course modules, content, and questions
 */

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  adminCourseAPI,
  adminCourseModuleAPI,
  adminCourseContentAPI,
  adminCardAPI
} from '../../services/adminApi';
import ModuleModal from '../../components/admin/ModuleModal';
import ContentModal from '../../components/admin/ContentModal';
import QuestionModal from '../../components/admin/QuestionModal';
import './ManageCourseContent.css';

const ManageCourseContent = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();

  const [course, setCourse] = useState(null);
  const [modules, setModules] = useState([]);
  const [contents, setContents] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('modules'); // modules, content, questions

  // Modal states
  const [showModuleModal, setShowModuleModal] = useState(false);
  const [showContentModal, setShowContentModal] = useState(false);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [showViewQuestionModal, setShowViewQuestionModal] = useState(false);

  const [editingModule, setEditingModule] = useState(null);
  const [editingContent, setEditingContent] = useState(null);
  const [editingQuestion, setEditingQuestion] = useState(null);
  const [viewingQuestion, setViewingQuestion] = useState(null);

  // Load data
  useEffect(() => {
    loadData();
  }, [courseId]);

  const loadData = async () => {
    try {
      setLoading(true);
      console.log('Loading course data for courseId:', courseId);
      const [courseRes, modulesRes, contentsRes, questionsRes] = await Promise.all([
        adminCourseAPI.getById(courseId),
        adminCourseModuleAPI.getByCourse(courseId),
        adminCourseContentAPI.getByCourse(courseId),
        adminCardAPI.getByCourse(courseId)
      ]);

      console.log('Raw questions response:', questionsRes.data);

      setCourse(courseRes.data.data);

      // Ensure we always set arrays
      setModules(Array.isArray(modulesRes.data.data) ? modulesRes.data.data : []);
      setContents(Array.isArray(contentsRes.data.data) ? contentsRes.data.data : []);

      // Questions might be in data.cards, data.data.cards, or data.data
      const questionData = questionsRes.data.data || questionsRes.data;
      console.log('Parsed questionData:', questionData);

      let finalQuestions = [];
      if (Array.isArray(questionData?.cards)) {
        finalQuestions = questionData.cards;
      } else if (Array.isArray(questionData)) {
        finalQuestions = questionData;
      } else {
        console.warn('Unexpected question data structure:', questionData);
        finalQuestions = [];
      }

      console.log('Final questions to display:', finalQuestions);
      console.log('Number of questions:', finalQuestions.length);
      setQuestions(finalQuestions);

      console.log('Successfully loaded course data:', {
        course: courseRes.data.data?.title,
        modulesCount: modulesRes.data.data?.length || 0,
        contentsCount: contentsRes.data.data?.length || 0,
        questionsCount: finalQuestions.length
      });
    } catch (error) {
      console.error('Error loading data:', error);
      console.error('Error details:', error.response?.data || error.message);
      alert(`Failed to load course data: ${error.response?.data?.error || error.message}`);
      // Reset to safe defaults on error
      setModules([]);
      setContents([]);
      setQuestions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAddModule = () => {
    setEditingModule(null);
    setShowModuleModal(true);
  };

  const handleEditModule = (module) => {
    setEditingModule(module);
    setShowModuleModal(true);
  };

  const handleDeleteModule = async (moduleId) => {
    if (!window.confirm('Delete this module? All content and questions in this module will be unlinked.')) {
      return;
    }

    try {
      await adminCourseModuleAPI.delete(moduleId);
      await loadData();
    } catch (error) {
      console.error('Error deleting module:', error);
      alert('Failed to delete module');
    }
  };

  const handleAddContent = (moduleId = null) => {
    setEditingContent({ moduleId });
    setShowContentModal(true);
  };

  const handleEditContent = (content) => {
    setEditingContent(content);
    setShowContentModal(true);
  };

  const handleDeleteContent = async (contentId) => {
    if (!window.confirm('Delete this content?')) {
      return;
    }

    try {
      await adminCourseContentAPI.delete(contentId);
      await loadData();
    } catch (error) {
      console.error('Error deleting content:', error);
      alert('Failed to delete content');
    }
  };

  const handleAddQuestion = (moduleId = null) => {
    setEditingQuestion({ moduleId });
    setShowQuestionModal(true);
  };

  const handleEditQuestion = (question) => {
    setEditingQuestion(question);
    setShowQuestionModal(true);
  };

  const handleViewQuestion = (question) => {
    setViewingQuestion(question);
    setShowViewQuestionModal(true);
  };

  const handleDeleteQuestion = async (questionId) => {
    if (!window.confirm('Delete this question?')) {
      return;
    }

    try {
      await adminCardAPI.delete(questionId);
      await loadData();
    } catch (error) {
      console.error('Error deleting question:', error);
      alert('Failed to delete question');
    }
  };

  if (loading) {
    return (
      <div className="manage-content-page">
        <div className="loading">Loading course data...</div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="manage-content-page">
        <div className="error">Course not found</div>
      </div>
    );
  }

  return (
    <div className="manage-content-page">
      {/* Header */}
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate('/admin/courses')}>
          ← Back to Courses
        </button>
        <div className="header-content">
          <div className="course-info">
            <span className="course-icon">{course.icon}</span>
            <div>
              <h1>{course.title}</h1>
              <p className="course-description">{course.description}</p>
            </div>
          </div>
          <div className="course-stats">
            <div className="stat">
              <span className="stat-value">{modules.length}</span>
              <span className="stat-label">Modules</span>
            </div>
            <div className="stat">
              <span className="stat-value">{contents.length}</span>
              <span className="stat-label">Content</span>
            </div>
            <div className="stat">
              <span className="stat-value">{questions.length}</span>
              <span className="stat-label">Questions</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs">
        <button
          className={`tab ${activeTab === 'modules' ? 'active' : ''}`}
          onClick={() => setActiveTab('modules')}
        >
          📚 Modules
        </button>
        <button
          className={`tab ${activeTab === 'content' ? 'active' : ''}`}
          onClick={() => setActiveTab('content')}
        >
          📁 Content & Files
        </button>
        <button
          className={`tab ${activeTab === 'questions' ? 'active' : ''}`}
          onClick={() => setActiveTab('questions')}
        >
          ❓ Questions
        </button>
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {activeTab === 'modules' && (
          <ModulesTab
            modules={modules}
            onAdd={handleAddModule}
            onEdit={handleEditModule}
            onDelete={handleDeleteModule}
          />
        )}

        {activeTab === 'content' && (
          <ContentTab
            contents={contents}
            modules={modules}
            onAdd={handleAddContent}
            onEdit={handleEditContent}
            onDelete={handleDeleteContent}
          />
        )}

        {activeTab === 'questions' && (
          <QuestionsTab
            questions={questions}
            modules={modules}
            onAdd={handleAddQuestion}
            onView={handleViewQuestion}
            onEdit={handleEditQuestion}
            onDelete={handleDeleteQuestion}
          />
        )}
      </div>

      {/* Modals */}
      {showModuleModal && (
        <ModuleModal
          courseId={courseId}
          module={editingModule}
          onClose={() => setShowModuleModal(false)}
          onSave={loadData}
        />
      )}

      {showContentModal && (
        <ContentModal
          courseId={courseId}
          content={editingContent}
          modules={modules}
          onClose={() => setShowContentModal(false)}
          onSave={loadData}
        />
      )}

      {showQuestionModal && (
        <QuestionModal
          courseId={courseId}
          question={editingQuestion}
          modules={modules}
          onClose={() => {
            setShowQuestionModal(false);
            setEditingQuestion(null);
          }}
          onSave={async () => {
            await loadData();
          }}
        />
      )}

      {showViewQuestionModal && viewingQuestion && (
        <ViewQuestionModal
          question={viewingQuestion}
          modules={modules}
          onClose={() => {
            setShowViewQuestionModal(false);
            setViewingQuestion(null);
          }}
        />
      )}
    </div>
  );
};

// ============================================
// Modules Tab Component
// ============================================
const ModulesTab = ({ modules, onAdd, onEdit, onDelete }) => {
  return (
    <div className="modules-tab">
      <div className="tab-header">
        <h2>Course Modules</h2>
        <button className="btn-primary" onClick={onAdd}>
          + Add Module
        </button>
      </div>

      {modules.length === 0 ? (
        <div className="empty-state">
          <p>No modules yet. Create your first module to organize your course content!</p>
          <button className="btn-primary" onClick={onAdd}>
            + Create First Module
          </button>
        </div>
      ) : (
        <div className="modules-list">
          {modules.map((module) => (
            <div key={module.id} className="module-card">
              <div className="module-icon">{module.icon}</div>
              <div className="module-info">
                <h3>{module.title}</h3>
                <p>{module.description}</p>
                <div className="module-meta">
                  {module.estimatedDuration && (
                    <span className="duration">⏱️ {module.estimatedDuration} min</span>
                  )}
                  <span className="content-count">
                    {module.contents?.length || 0} items
                  </span>
                  <span className="question-count">
                    {module.questions?.length || 0} questions
                  </span>
                </div>
              </div>
              <div className="module-actions">
                <button className="btn-edit" onClick={() => onEdit(module)}>
                  Edit
                </button>
                <button className="btn-delete" onClick={() => onDelete(module.id)}>
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ============================================
// Content Tab Component
// ============================================
const ContentTab = ({ contents, modules, onAdd, onEdit, onDelete }) => {
  const getContentIcon = (type) => {
    const icons = {
      video: '🎥',
      pdf: '📄',
      document: '📝',
      link: '🔗',
      image: '🖼️',
      audio: '🎵'
    };
    return icons[type] || '📁';
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '';
    const mb = bytes / (1024 * 1024);
    return mb < 1 ? `${(mb * 1024).toFixed(0)} KB` : `${mb.toFixed(1)} MB`;
  };

  return (
    <div className="content-tab">
      <div className="tab-header">
        <h2>Course Content & Files</h2>
        <button className="btn-primary" onClick={() => onAdd()}>
          + Add Content
        </button>
      </div>

      {contents.length === 0 ? (
        <div className="empty-state">
          <p>No content yet. Add videos, PDFs, or documents to enrich your course!</p>
          <button className="btn-primary" onClick={() => onAdd()}>
            + Add First Content
          </button>
        </div>
      ) : (
        <div className="content-list">
          {contents.map((content) => (
            <div key={content.id} className="content-card">
              <div className="content-icon">{getContentIcon(content.contentType)}</div>
              <div className="content-info">
                <h3>{content.title}</h3>
                <p>{content.description}</p>
                <div className="content-meta">
                  <span className="content-type">{content.contentType}</span>
                  {content.fileSize && (
                    <span className="file-size">{formatFileSize(content.fileSize)}</span>
                  )}
                  {content.module && (
                    <span className="module-badge">{content.module.title}</span>
                  )}
                  {content.isFree && <span className="free-badge">FREE</span>}
                </div>
              </div>
              <div className="content-actions">
                <button className="btn-edit" onClick={() => onEdit(content)}>
                  Edit
                </button>
                <button className="btn-delete" onClick={() => onDelete(content.id)}>
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ============================================
// Questions Tab Component
// ============================================
const QuestionsTab = ({ questions, modules, onAdd, onView, onEdit, onDelete }) => {
  const getQuestionTypeLabel = (type) => {
    const labels = {
      basic: 'Short Answer',
      multiple_choice: 'Multiple Choice',
      cloze: 'Fill in the Blanks',
      image: 'Picture Quiz'
    };
    return labels[type] || type;
  };

  const getQuestionTypeIcon = (type) => {
    const icons = {
      basic: '📝',
      multiple_choice: '☑️',
      cloze: '✍️',
      image: '🖼️'
    };
    return icons[type] || '❓';
  };

  return (
    <div className="questions-tab">
      <div className="tab-header">
        <h2>Practice Questions</h2>
        <button className="btn-primary" onClick={() => onAdd()}>
          + Add Question
        </button>
      </div>

      <div className="question-types-info">
        <div className="info-card">
          <span className="icon">📝</span>
          <div>
            <strong>Short Questions</strong>
            <p>Students type their answer</p>
          </div>
        </div>
        <div className="info-card">
          <span className="icon">✍️</span>
          <div>
            <strong>Fill in the Blanks</strong>
            <p>Complete the sentence</p>
          </div>
        </div>
        <div className="info-card">
          <span className="icon">☑️</span>
          <div>
            <strong>Multiple Choice</strong>
            <p>Select the correct answer</p>
          </div>
        </div>
      </div>

      {questions.length === 0 ? (
        <div className="empty-state">
          <p>No questions yet. Add practice questions to help students learn!</p>
          <button className="btn-primary" onClick={() => onAdd()}>
            + Add First Question
          </button>
        </div>
      ) : (
        <div className="questions-list">
          {questions.map((question) => (
            <div key={question.id} className="question-card">
              <div className="question-type-icon">
                {getQuestionTypeIcon(question.cardType)}
              </div>
              <div className="question-info">
                <div className="question-header">
                  <span className="question-type-badge">
                    {getQuestionTypeLabel(question.cardType)}
                  </span>
                  {question.module && (
                    <span className="module-badge">{question.module.title}</span>
                  )}
                </div>
                <h3>{question.question}</h3>
                <p className="answer-preview">
                  <strong>Answer:</strong> {question.answer}
                </p>
                {question.hint && (
                  <p className="hint-preview">
                    <strong>Hint:</strong> {question.hint}
                  </p>
                )}
                {question.cardType === 'multiple_choice' && question.options && (
                  <div className="options-preview">
                    {question.options.map((opt, idx) => (
                      <span key={idx} className="option-badge">
                        {opt}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="question-actions">
                <button className="btn-view" onClick={() => onView(question)}>
                  View
                </button>
                <button className="btn-edit" onClick={() => onEdit(question)}>
                  Edit
                </button>
                <button className="btn-delete" onClick={() => onDelete(question.id)}>
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="sm2-info">
        <div className="info-box">
          <h4>📊 SM-2 Spaced Repetition Algorithm</h4>
          <p>
            All questions use the SM-2 algorithm to optimize learning. Questions will appear
            to students based on their performance, ensuring efficient retention and mastery.
          </p>
        </div>
      </div>
    </div>
  );
};

// ============================================
// View Question Modal Component
// ============================================
const ViewQuestionModal = ({ question, modules, onClose }) => {
  const getQuestionTypeLabel = (type) => {
    const labels = {
      basic: 'Short Answer',
      multiple_choice: 'Multiple Choice',
      cloze: 'Fill in the Blanks',
      image: 'Picture Quiz',
      ordered: 'Order Items',
      true_false: 'True/False',
      multi_select: 'Multi-Select',
      matching: 'Matching',
      categorization: 'Categorization'
    };
    return labels[type] || type;
  };

  const moduleName = question.moduleId
    ? modules.find(m => m.id === question.moduleId)?.title
    : 'No Module';

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>View Question</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>

        <div className="modal-body">
          <div className="view-field">
            <label>Question Type:</label>
            <p className="type-badge">{getQuestionTypeLabel(question.cardType)}</p>
          </div>

          {question.moduleId && (
            <div className="view-field">
              <label>Module:</label>
              <p>{moduleName}</p>
            </div>
          )}

          <div className="view-field">
            <label>Question:</label>
            <p className="question-text">{question.question}</p>
          </div>

          <div className="view-field">
            <label>Answer:</label>
            <p className="answer-text">{question.answer}</p>
          </div>

          {question.hint && (
            <div className="view-field">
              <label>Hint:</label>
              <p className="hint-text">{question.hint}</p>
            </div>
          )}

          {question.explanation && (
            <div className="view-field">
              <label>Explanation:</label>
              <p className="explanation-text">{question.explanation}</p>
            </div>
          )}

          {question.cardType === 'multiple_choice' && question.options && (
            <div className="view-field">
              <label>Options:</label>
              <ul className="options-list">
                {question.options.map((opt, idx) => (
                  <li key={idx} className={opt === question.answer ? 'correct-option' : ''}>
                    {opt} {opt === question.answer && '✓'}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {question.cardType === 'multi_select' && question.options && (
            <div className="view-field">
              <label>Options:</label>
              <ul className="options-list">
                {question.options.map((opt, idx) => (
                  <li key={idx} className={question.multiSelectAnswers?.includes(opt) ? 'correct-option' : ''}>
                    {opt} {question.multiSelectAnswers?.includes(opt) && '✓'}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {question.cardType === 'ordered' && question.orderedItems && (
            <div className="view-field">
              <label>Correct Order:</label>
              <ol className="ordered-items-list">
                {question.orderedItems.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ol>
            </div>
          )}

          {question.cardType === 'matching' && question.matchingPairs && (
            <div className="view-field">
              <label>Matching Pairs:</label>
              <div className="matching-pairs">
                {question.matchingPairs.map((pair, idx) => (
                  <div key={idx} className="pair">
                    <span className="left">{pair.left}</span>
                    <span className="arrow">→</span>
                    <span className="right">{pair.right}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {question.cardType === 'categorization' && question.categories && (
            <div className="view-field">
              <label>Categories:</label>
              <div className="categories-view">
                {Object.entries(question.categories).map(([category, items]) => (
                  <div key={category} className="category-group">
                    <h4>{category}</h4>
                    <ul>
                      {items.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}

          {question.cardType === 'image' && question.imageUrl && (
            <div className="view-field">
              <label>Image:</label>
              <img src={question.imageUrl} alt="Question" className="question-image" />
              {question.occludedRegions && (
                <div className="occluded-regions-info">
                  <p>Occluded Regions: {question.occludedRegions.length}</p>
                </div>
              )}
            </div>
          )}

          {question.tags && question.tags.length > 0 && (
            <div className="view-field">
              <label>Tags:</label>
              <div className="tags-list">
                {question.tags.map((tag, idx) => (
                  <span key={idx} className="tag-badge">{tag}</span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="modal-footer">
          <button className="btn-secondary" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
};

export default ManageCourseContent;
