import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import './Homepage.css';

const Homepage = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [featuredCourses, setFeaturedCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // If user is already logged in, redirect to dashboard
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    fetchFeaturedCourses();
  }, []);

  const fetchFeaturedCourses = async () => {
    try {
      const response = await api.get('/public/courses');
      setFeaturedCourses(response.data);
    } catch (error) {
      console.error('Error fetching courses:', error);
    } finally {
      setLoading(false);
    }
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const features = [
    {
      icon: '🎯',
      title: '9 Card Types',
      description: 'Multiple choice, image occlusion, cloze deletion, matching pairs, and more for diverse learning.'
    },
    {
      icon: '🧠',
      title: 'Smart Spaced Repetition',
      description: 'SM-2 algorithm adapts to your learning pace with personalized review schedules.'
    },
    {
      icon: '🏆',
      title: 'Gamification',
      description: 'Earn XP, level up, collect achievements, and maintain your study streak.'
    },
    {
      icon: '📚',
      title: 'Advanced Study Tools',
      description: 'Pomodoro timer, smart planner, study calendar, and integrated notes manager.'
    },
    {
      icon: '📊',
      title: 'Progress Tracking',
      description: 'Detailed analytics and performance charts to monitor your mastery level.'
    },
    {
      icon: '🌙',
      title: 'Beautiful Themes',
      description: 'Gorgeous dark and light themes with smooth transitions for comfortable studying.'
    }
  ];

  const howItWorks = [
    {
      step: 1,
      title: 'Create Your Account',
      description: 'Sign up for free in seconds and get instant access to all features.',
      icon: '👤'
    },
    {
      step: 2,
      title: 'Choose Your Courses',
      description: 'Browse our catalog and enroll in courses that match your learning goals.',
      icon: '📖'
    },
    {
      step: 3,
      title: 'Study Smart',
      description: 'Learn with spaced repetition, track progress, and earn achievements.',
      icon: '🎓'
    },
    {
      step: 4,
      title: 'Master Subjects',
      description: 'Watch your knowledge grow with our intelligent review system.',
      icon: '⭐'
    }
  ];

  const getDifficultyColor = (difficulty) => {
    switch(difficulty) {
      case 'beginner': return '#10B981';
      case 'intermediate': return '#F59E0B';
      case 'advanced': return '#EF4444';
      default: return '#6B7280';
    }
  };

  return (
    <div className="homepage">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-background">
          <div className="hero-gradient"></div>
        </div>
        <div className="hero-content">
          <div className="hero-text">
            <h1 className="hero-title">
              Supercharge Your Learning
              <br />
              <span className="hero-highlight">with Next-Gen AI Study System</span>
            </h1>
            <p className="hero-subtitle">
              Learn faster and remember longer with AI-powered spaced repetition,
              gamification, and 9 interactive card types. Join thousands of students
              achieving their learning goals.
            </p>
            <div className="hero-cta">
              <Link to="/register" className="btn btn-primary btn-large">
                Get Started Free
              </Link>
              <button
                onClick={() => scrollToSection('courses-section')}
                className="btn btn-secondary btn-large"
              >
                Explore Courses
              </button>
            </div>
            <div className="hero-stats">
              <div className="stat-item">
                <span className="stat-number">10,000+</span>
                <span className="stat-label">Flashcards</span>
              </div>
              <div className="stat-item">
                <span className="stat-number">500+</span>
                <span className="stat-label">Students</span>
              </div>
              <div className="stat-item">
                <span className="stat-number">50+</span>
                <span className="stat-label">Courses</span>
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-card-demo">
              <div className="demo-card">
                <div className="demo-card-header">
                  <span className="demo-badge">Flashcard Preview</span>
                </div>
                <div className="demo-card-content">
                  <div className="demo-question">What is the capital of France?</div>
                  <div className="demo-answer">Paris</div>
                </div>
                <div className="demo-card-footer">
                  <span className="demo-tag">Geography</span>
                  <span className="demo-difficulty">Beginner</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section" id="features-section">
        <div className="section-container">
          <div className="section-header">
            <h2 className="section-title">Powerful Features for Effective Learning</h2>
            <p className="section-subtitle">
              Everything you need to master any subject, all in one place
            </p>
          </div>
          <div className="features-grid">
            {features.map((feature, index) => (
              <div key={index} className="feature-card">
                <div className="feature-icon">{feature.icon}</div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-description">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section className="courses-section" id="courses-section">
        <div className="section-container">
          <div className="section-header">
            <h2 className="section-title">Featured Courses</h2>
            <p className="section-subtitle">
              Start learning today with our curated selection of courses
            </p>
          </div>
          {loading ? (
            <div className="courses-loading">
              <div className="loading-spinner"></div>
              <p>Loading courses...</p>
            </div>
          ) : featuredCourses.length > 0 ? (
            <div className="courses-grid">
              {featuredCourses.map((course) => (
                <div key={course.id} className="course-card">
                  <div className="course-icon" style={{ backgroundColor: course.color || '#10B981' }}>
                    {course.icon || '📚'}
                  </div>
                  <div className="course-content">
                    <div className="course-header">
                      <h3 className="course-title">{course.title}</h3>
                      {course.isFree && (
                        <span className="course-badge free-badge">Free</span>
                      )}
                    </div>
                    <p className="course-description">{course.description}</p>
                    <div className="course-meta">
                      <span
                        className="course-difficulty"
                        style={{ color: getDifficultyColor(course.difficulty) }}
                      >
                        {course.difficulty || 'Beginner'}
                      </span>
                      <span className="course-cards">
                        {course.totalCards || 0} cards
                      </span>
                    </div>
                    <Link to="/register" className="course-cta">
                      Enroll Now
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="courses-empty">
              <p>No courses available yet. Check back soon!</p>
            </div>
          )}
          <div className="courses-cta">
            <Link to="/register" className="btn btn-primary">
              View All Courses
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="how-it-works-section">
        <div className="section-container">
          <div className="section-header">
            <h2 className="section-title">How FlashMind Works</h2>
            <p className="section-subtitle">
              Your journey to mastery in four simple steps
            </p>
          </div>
          <div className="steps-container">
            {howItWorks.map((item, index) => (
              <div key={index} className="step-card">
                <div className="step-number">{item.step}</div>
                <div className="step-icon">{item.icon}</div>
                <h3 className="step-title">{item.title}</h3>
                <p className="step-description">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-content">
          <h2 className="cta-title">Ready to Start Learning?</h2>
          <p className="cta-subtitle">
            Join thousands of students who are already mastering new subjects with FlashMind
          </p>
          <div className="cta-buttons">
            <Link to="/register" className="btn btn-primary btn-large">
              Sign Up Free
            </Link>
            <Link to="/login" className="btn btn-secondary btn-large">
              Login
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="homepage-footer">
        <div className="footer-content">
          <div className="footer-section">
            <h3 className="footer-title">FlashMind</h3>
            <p className="footer-description">
              The smart way to learn and remember anything.
            </p>
          </div>
          <div className="footer-section">
            <h4 className="footer-heading">Product</h4>
            <ul className="footer-links">
              <li><button onClick={() => scrollToSection('features-section')}>Features</button></li>
              <li><button onClick={() => scrollToSection('courses-section')}>Courses</button></li>
              <li><Link to="/register">Pricing</Link></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4 className="footer-heading">Company</h4>
            <ul className="footer-links">
              <li><a href="#about">About</a></li>
              <li><a href="#contact">Contact</a></li>
              <li><a href="#privacy">Privacy Policy</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h4 className="footer-heading">Get Started</h4>
            <ul className="footer-links">
              <li><Link to="/register">Sign Up</Link></li>
              <li><Link to="/login">Login</Link></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2025 FlashMind. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Homepage;
